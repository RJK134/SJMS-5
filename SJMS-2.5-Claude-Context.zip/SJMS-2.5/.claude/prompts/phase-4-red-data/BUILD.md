# phase-4-red-data — BUILD PROMPT
See SJMS-2.5-Build-and-Verify-Prompts.docx for full prompt content.
Copy the corresponding phase prompt from the document into this file before executing.
